﻿private System.Windows.Forms.TextBox txtUsername;
private System.Windows.Forms.TextBox txtPassword;
private System.Windows.Forms.Button btnLogin;

namespace login
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            // Aqui você faria a verificação das credenciais, por exemplo:
            if (username == "admin" && password == "123456")
            {
                MessageBox.Show("Login bem-sucedido!");
                // Fechar o formulário de login
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Nome de usuário ou senha inválidos. Tente novamente.");
            }
        }
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Text = "LOGIN";

            // Adicionando TextBox para o nome de usuário
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtUsername.Location = new System.Drawing.Point(100, 100);
            this.Controls.Add(this.txtUsername);

            // Adicionando TextBox para a senha
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtPassword.Location = new System.Drawing.Point(100, 150);
            this.txtPassword.PasswordChar = '*'; // Para ocultar a senha
            this.Controls.Add(this.txtPassword);

            // Adicionando botão de login
            this.btnLogin = new System.Windows.Forms.Button();
            this.btnLogin.Location = new System.Drawing.Point(100, 200);
            this.btnLogin.Text = "Login";
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            this.Controls.Add(this.btnLogin);
        }


        #endregion
    }
}
